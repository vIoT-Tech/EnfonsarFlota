function generaqr(){

$(document).ready(function(){

       var elnom =document.getElementById('nom').value; 
       var elcognom =document.getElementById('cognom').value;
       var elmail =document.getElementById('mail').value;
       
       var tot = (elnom + elcognom + elmail);
       //alert(tot);
       
       $('#qrcode').qrcode({
	 text: 'Nom: ' + elnom + '</br>' + 'Cognom: ' + elcognom + '</br>' + 'Mail: ' + elmail
        });
});
}