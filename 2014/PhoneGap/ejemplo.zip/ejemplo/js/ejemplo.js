function saludar(){
       var nom =document.getElementById('nombre').value; 
       alert("Hola " + nom);
}
